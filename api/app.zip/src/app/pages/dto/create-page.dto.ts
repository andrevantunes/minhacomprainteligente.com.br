export class CreatePageDto {
  path: string;
  value: any;
}
